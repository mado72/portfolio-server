'use strict';


/**
 * Get price for a asset ticker
 * It gets from yahoo finance the actual price of a ticker defined at path variable
 *
 * ticker String 
 * returns YahooQuoteResponse
 **/
exports.getYahooPriceTicker = function(ticker) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "language" : "language",
  "region" : "region"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

